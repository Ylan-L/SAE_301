#!/usr/bin/env python3
"""
Détecte et affiche un type suggéré par colonne pour deux fichiers CSV
Ordre: REPHY_Manche_Atlantique_1987-2022.csv puis REPHY_Med_1987-2022_lacbon.csv

Usage:
  python detect_column_types.py            # utilise les fichiers par défaut
  python detect_column_types.py file1 file2

Sortie: affiche le nom de colonne et un type suggéré (nu, date, integer, float,
boolean, varchar(n), text).
"""
import sys
from pathlib import Path
from typing import List, Tuple

try:
    import pandas as pd
except Exception:
    print("Erreur: pandas est requis. Installez via 'pip install -r requirements.txt'")
    raise

import io
import csv

DEFAULT_FILES = [
    "REPHY_Manche_Atlantique_1987-2022.csv",
    "REPHY_Med_1987-2022_lacbon.csv",
]


def infer_type(s: pd.Series) -> str:
    s_orig = s
    s = s.dropna().astype(str).str.strip()
    if s.empty:
        return "nu"

    # faible cardinalité booleans
    low = s.str.lower()
    if low.isin(["true", "false", "0", "1", "yes", "no", "y", "n"]).all():
        return "boolean"

    # numérique
    num = pd.to_numeric(s, errors="coerce")
    num_frac = num.notna().mean()
    if num_frac >= 0.95:
        # si tous entiers
        non_na = num.dropna()
        if (non_na % 1 == 0).all():
            return "integer"
        return "float"

    # date
    dt = pd.to_datetime(s, errors="coerce", infer_datetime_format=True)
    dt_frac = dt.notna().mean()
    if dt_frac >= 0.9:
        return "date"

    # texte / varchar
    lengths = s.map(len)
    maxlen = int(lengths.max())
    if maxlen > 255:
        return "text"
    return f"varchar({maxlen})"


def read_csv_with_encoding(path: Path, nrows: int = 20000) -> Tuple[pd.DataFrame, str, str]:
    # Essaie plusieurs encodages et tente une détection avec chardet si disponible
    encodings = ["utf-8", "utf-8-sig", "cp1252", "latin-1"]
    # try chardet detection
    raw = path.read_bytes()
    try:
        import chardet
        guess = chardet.detect(raw[:100000]) if raw else {}
        enc = guess.get("encoding") if isinstance(guess, dict) else None
        if enc:
            encodings = [enc] + encodings
    except Exception:
        enc = None

    # detect possible delimiter using csv.Sniffer on a decoded sample
    sample_text = None
    detected_sep = None
    for e in dict.fromkeys(encodings):
        try:
            sample_text = raw[:20000].decode(e, errors="replace")
            break
        except Exception:
            sample_text = None
    if sample_text:
        try:
            sniffer = csv.Sniffer()
            dialect = sniffer.sniff(sample_text, delimiters=[',',';','\t','|'])
            detected_sep = dialect.delimiter
        except Exception:
            detected_sep = None

    last_exc = None
    for e in dict.fromkeys(encodings):
        try:
            # choose sep from detection or let pandas infer
            sep = detected_sep if detected_sep else None
            # try fast C engine first
            df = pd.read_csv(path, encoding=e, sep=sep, nrows=nrows, low_memory=False)
            return df, e, sep
        except Exception as first_exc:
            last_exc = first_exc
            # try using python engine with sep guessed (helps mismatched fields)
            try:
                df = pd.read_csv(path, encoding=e, sep=detected_sep if detected_sep else ',', engine='python')
                return df, e, (detected_sep if detected_sep else ',')
            except Exception as second_exc:
                last_exc = second_exc
                continue
    raise last_exc


def analyze_file(path: Path, nrows: int = 20000) -> List[str]:
    if not path.exists():
        return [f"Fichier non trouvé: {path}"]

    try:
        df, used_enc, used_sep = read_csv_with_encoding(path, nrows=nrows)
    except Exception as e:
        return [f"Erreur lecture {path.name}: {e}"]

    results = [f"(encodage utilisé: {used_enc}, séparateur détecté: {used_sep})"]
    for col in df.columns:
        col_series = df[col]
        suggested = infer_type(col_series)
        null_pct = 100.0 * col_series.isna().mean()
        results.append(f"{col}: {suggested} (null%={null_pct:.1f})")
    # résumé demandé: préciser lequel des fichiers et son type après
    results.append(f"Fichier: {path.name} — type: csv — encodage: {used_enc} — séparateur: '{used_sep}'")
    return results


def main(argv):
    files = argv[1:]
    if not files:
        files = DEFAULT_FILES

    first = True
    for fp in files:
        path = Path(fp)
        header = f"----- {path.name} -----"
        if not first:
            # séparateur demandé explicitement
            print("\n==================== SEPARATEUR ====================\n")
        first = False
        print(header)
        for line in analyze_file(path):
            print(line)


if __name__ == "__main__":
    main(sys.argv)
